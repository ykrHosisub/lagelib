# Worklog

---
Task ID: 1
Agent: main (Z.ai)
Task: v1.2 アップデート — 草むら修正 / カメラ修正 / 一人称視点操作 / 廃坑マップ追加 / 道路上の草むら禁止 / ルーミー衣装変更

Work Log:
- types.ts: MapId に 'mine' 追加、gimmick に 'mine'、MapDef に platforms/walkways フィールド追加
- maps.ts: 草むらチェーンを全面再設計 (72点→21点、道路/川/壁から全点8.5以上離す・検証スクリプト済み)。MINE_PLATFORMS (12個の円形足場) / MINE_WALKWAYS (6本の桟道) / MINE_BUSHES / MINE_NEUTRAL_SPOTS を追加。廃坑マップ「アビス・廃坑橋」を MAPS に追加
- world.ts: buildBush を軽量化&草っぽく (背の高い円錐→幅広低い草束+潰した球、影オフ、メッシュ数 30→最大9/rect、sway対象を絞る)。buildMineTerrain 追加 (奈落・木板テクスチャの橋・手すり柱・トロッコ用レール・桟道・岩棚・橋下の浮遊結晶)。decor に pitprop/cart/orevein 追加。廃坑は木の壁色
- battle.ts: カメラをフレームレート非依存の指数平滑に修正 (camPos + camLook 注視点スムージング=WASDのガクつき解消)、rig表示用yaw DispYaw を最短角補間。一人称視線 viewYaw/viewPitch 追加 (PC: ポインタロック+mousemove / スマホ: lookDelta API)、ズーム≥0.6で自動ロック解除。廃坑ギミック実装 (isWalkableMine/nearestWalkableMine/updateMineFalls: 落下600ダメージ鎧無視+沈む演出+最寄り足場へ救出、updateMinecart: 中央橋を暴走トロッコ240+ダメージ+ノックバック、updateOreVeins: 銀鉱脈+90ゴールド)。ニュートラル配置をマップ別に
- models.ts: ルーミーを白いふわふわおむつ風キュロット+前リボン+腰リボン+足カフに変更 (フリルとは分岐)
- characters.ts: ルーミーの説明文を新衣装ベースに更新
- Selects.tsx: 廃坑マップのプレビューカード (奈落+橋+トロッコ+結晶) 追加
- BattleView.tsx: スマホ一人称ドラッグ見回しゾーン (zoom<0.3で右2/3に出現、なぞって視点移動)
- 検証: tsc / next build 成功。headlessブラウザで実機テスト — 廃坑マップ起動・落下600ダメージ+テレポート・トロッコ起動・鉱脈4つ・一人称視点・草むらの見た目・隠密表示を全て確認

Stage Summary:
- 全10タスク完了、v1.2 としてコミット済み
- 廃坑マップは橋の上のみ歩行可能、落ちると600ダメージ+最寄りの橋/足場へ戻される
- 草むらは道路上から完全撤去、数も約1/3に減り描画も軽量化 (影オフ)
- 一人称: PC=クリックでマウス視点 (ポインタロック)、スマホ=画面をなぞる
- カメラのWASD方向転換時のがくつきは位置/注視点/モデル回転の3重スムージングで解消

---
Task ID: 2
Agent: main (Z.ai)
Task: v1.3 — 廃坑マップ軽量化 / 落下演出改善 / 全体60FPS化 (画質・機能は変えずに)

Work Log:
- world.ts: GeoBatch (静的ジオメトリのマテリアル別統合ヘルパ) 追加。buildMineTerrain をバッチ化 (橋/桟道/手すり/柱78本/岩棚/岩柱 → 8メッシュ、行列自動更新オフ)。makeGlowSprite (加算合成の放射グラデ擬似ライト) 追加
- world.ts: 全デコレーションのPointLight (torch/campfire/crystal/lantern/pitprop/station platform/crossgate) を擬似ライトスプライトに置換 — 上空カメラからはほぼ同じ見た目、ライト数は大幅減
- battle.ts: 弾丸ごとのPointLight廃止 (ライト数変動がシェーダ再コンパイルのスパイクを引き起こす最大要因だった)。トロッコ/鉱脈/電車ヘッドライト/オーブのライトも全て擬似スプライト化 → 廃坑のライト数 29→8
- battle.ts: ミニオンメッシュを頂点色3バケット (布/金属/発光) に統合+ジオメトリ/マテリアル全共有 (10メッシュ→3、最大640→190描画呼び出し)。死亡フェードはマテリアル複製方式。mergeGeometries の indexed/non-indexed 混在クラッシュを toNonIndexed 正規化で修正
- battle.ts: シャドウパス隔フレーム更新 (shadowMap.autoUpdate=false + needsUpdate 30Hz)、頭上HPバー30Hz化、updateCamera/drawPlates の毎フレームVector3アロケーション廃止、クールダウン/バフ配列の毎フレーム再生成廃止
- battle.ts: 落下演出を刷新 — 0.55秒の直線沈み→0.9秒の重力放物線 (k²加速) + 前転タンブル回転 + 落下中の岩屑ストリーク + 足場崩れ砂煙 + 救出着地エフェクト強化。落下中はカメラの注視点が落ちていく自分を追う
- audio.ts: fall (風切り音) / fall-soft (他チャンプ落下) / rescue (着地+ほっと音) の新SE追加
- BattleView.tsx: ダメージ数字を140ms間隔の一括フラッシュに変更 (激戦時の再レンダーストーム防止)
- 検証: tsc/next build 成功。headless実測 — 廃坑でライト29→8 (-72%)、描画呼び出し519→412/フレーム (-21%)、ソフト描画841ms→344ms/フレーム (2.4倍高速=30FPS→60FPS+相当)。落下演出 (rootY放物線+rotXタンブル)・救出転送・600ダメージ・ミニオン統合 (3メッシュ/体・ジオメトリ共有) を実機確認、コンソールエラーゼロ

Stage Summary:
- 廃坑マップ: ライト72%減・描画呼び出し21%減・CPU描画2.4倍高速化 (見た目はほぼ同一)
- 全マップ共通: シャドウ隔フレーム・頭上バー30Hz・GC削減・ダメージ数字バッチ化で安定60FPS向けに
- 落下は「重力で加速して落ちる」演出に (タンブル+風切り音+カメラ追従)
- v1.3 としてコミット予定

---
Task ID: 3
Agent: main (Z.ai)
Task: v1.4 — 廃坑Bot落下修正 / ルーミー健全化 / ボルト改善 / 新キャラ「ステラ」

Work Log:
- battle.ts: 廃坑の歩行可能判定を二層化 — isWalkableMine (連続・正確・落下判定用) + mineGrid (1mセルのUint8Array・事前計算・経路計画専用+0.4mマージン)。lineWalkableMine/mineWaypoint を追加
- battle.ts: ボットAIのmoveTowardを廃坑対応 — stepMineSafe (次の一歩が奈落なら12方向にスライド、全滅なら目標再計画) + 目標キャッシュ時に直線が通れない場合は mineWaypoint で橋をたどる中継点経由に切替。ミニオンの追尾も次の一歩が奈落ならレーン前進に戻す
- battle.ts: ボットのスキル使用に射程ゲート追加 (projectile/aoe/burst=range+1.6, dash=dashDist+1) — 従来は射程14でQ(射程10)を無駄撃ちしていた
- battle.ts: findAim のチャンピオン選択を「弱い敵&近い敵」スコア (hp% + dist*0.025) に変更 — ボットAIと同一基準で公平化 (プレイヤーの火力がタンクに無駄撃ちされる問題修正)
- characters.ts: ボルト再調整 (hp 940→1000, atk 104→112, armor 16→22, Q 0.78→0.95, E 0.62→0.75, R 2.1→2.45)。ルーミーの説明文をおむつ表記からピンクのワンピース表記に変更
- characters.ts: 新キャラ「ステラ」(星剣の天使/ファイター) 追加 — 13体目。stats: HP1270/atk124/射程5.5/speed6.9
- models.ts: greatsword武器 (星ジェム付き大剣) / halo帽子 (天使の輪+黄色ロングヘア+星ヘアピン) / ステラの背中の白い翼3枚羽+白金スカート / ルーミーをおむつ風パフパンツからピンク2段フレアワンピース+白ソックスに変更
- vfx.ts: 'sword'弾形状 (くるくる回転する大剣弾) / BeamPool.spawn にdur+radiusパラメータ追加
- battle.ts: ステラ通常攻撃 — 大剣が飛んでいく (近距離1.78×↔最大射程0.75×の距離火力・homing)。負荷メータ満タン時は通常攻撃の代わりに360度剣舞 (doStellaSpin: 半径4.6のAoE 1.75×atk+渦巻き光弧)
- battle.ts: ステラQ スターバースト — 360度に星6個出現し近くの敵にホーミング (spawnStarRing: 敵チャンプ→ミニオン→ニュートラル/ペットの順に割当)
- battle.ts: ステラE ステラッシュ — 3段コンボ (敵の背後→前→背後へワープ斬り 0.6/0.6/1.25×atk、最後に白黒演出 spawnMonoFx=灰色シェル+白黒粒子)
- battle.ts: ステラR ステライド — 十角形の対角線ジャンプ順 [0,3,6,9,2,5,8,1,4,7] で10回ダッシュ斬り (0.26×atk each + 星路の光跡ビーム) → 納刀 → 大魔法陣3重リング+十角ルーン → 天に向かう大ビーム+範囲1.35×atk
- battle.ts: コンボシステム (Champion.combo + updateStellaCombo、ccLockedにcombo追加、気絶/ひより/落下/死亡でキャンセル、コンボ中は移動攻撃スキル禁止)。負荷ゲージはapplyDamageの与ダメでチャンプ0.075/ミニオン0.045ずつ加算
- battle.ts: 頭上バーにステラの負荷ゲージ (金色+星マーク) 追加、buildHud に angerLabel 追加
- types.ts: hat 'halo' / weapon 'greatsword' / ProjShape 'sword' / SkillGlyph 3種 / SkillDef starRing+comboKind / HudSnapshot angerLabel
- SkillIcon.tsx: star-ring / star-slash / star-ride の3アイコン追加
- BattleView.tsx: ステラの負荷メータを体力バーの上に表示 (スマホ右上パネル+PC左下パネル、負荷MAXで「剣舞可」表示)
- BootTitle.tsx: ニュースをステラ参戦版に更新 (v1.4)
- 検証: tsc/next build 成功。headless実機テスト — キャラ選択にステラ表示 (13体)・3Dプレビュー (天使の輪+大剣+翼)・廃坑バトル起動・スキルアイコン3種・HUD正常を確認

Stage Summary:
- 廃坑でBotが落ち続ける問題をナビゲーション層から修正 (橋スライド+中継点経路)
- ボルトの「ボットが使うと強い/自分が使うと弱い」の非対称要素を3点修正+適度な buff
- ルーミーを普通のかわいいワンピースキャラに変更
- ステラ実装完了 (距離火力大剣/360度星/3段瞬斬コンボ/十角ULT/負荷メータ剣舞)

---
Task ID: zip-deliver
Agent: main (Z.ai)
Task: ゲーム全体のZIPファイルをダウンロード用にパッケージしてチャットに提示

Work Log:
- git 状態確認: v1.4 (c7a6acb) クリーンワークツリー、ステラ/廃坑Bot落下修正/ボルト公平性/ルーミー健全化すべて実装済み
- ZIP 同梱用 README-AETHER.md 作成（セットアップ手順・操作方法・プロジェクト構成を日本語で記載）
- zip コマンドでパッケージ化: src/ public/ prisma/ db/ mini-services/battle-server(ソースのみ) 設定ファイル群を同梱
- 除外: node_modules(1.3G) .next(255M) .git(81M) scripts(32Mの開発スクショ) skills/ examples/ tests/
- 検証: unzip -t OK / 121ファイル / src 93ファイル / 主要ファイル(characters.ts, maps.ts, battle.ts, GameApp.tsx, battle-server)同梱確認 / node_modules リークなし

Stage Summary:
- 成果物: /home/z/my-project/download/Aether-League-v1.4.zip (4.2MB / 121ファイル)
- 解凍後 bun install → bun run dev で動作可能な完全ソース一式
