'use client'

import dynamic from 'next/dynamic'

const GameApp = dynamic(() => import('@/components/game/GameApp'), {
  ssr: false,
  loading: () => (
    <div className="fixed inset-0 flex items-center justify-center bg-[#1a1030]">
      <div className="text-2xl">🌟</div>
    </div>
  ),
})

export default function Home() {
  return <GameApp />
}
