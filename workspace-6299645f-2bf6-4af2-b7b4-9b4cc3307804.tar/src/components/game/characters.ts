// ===== キャラクターデータ =====
// フリルは健全な元気キャラとして完全リニューアル。
// 旧スキルは廃止し、新スキル「フリル・レイジ」（怒りで周囲をひよらせる）を採用。

export interface CharacterSkill {
  name: string
  kana: string
  desc: string
  cooldown: number // 秒
}

export interface CharacterDef {
  id: string
  name: string
  title: string
  desc: string
  hp: number
  speed: number
  power: number
  color: string // テーマカラー
  hairColor: string
  dressColor: string
  accentColor: string
  unlocked: boolean
  lockReason?: string
  skill: CharacterSkill
}

export const FRILL_SKILL: CharacterSkill = {
  name: 'フリル・レイジ',
  kana: 'ふりる・れいじ',
  desc: 'フリルがキレて怒りのオーラを大爆発！周囲の敵はビクッとひよって、しばらく動きが鈍くなり後ずさりする。自分も怒りパワーで一時的に強くなる！',
  cooldown: 12,
}

export const CHARACTERS: CharacterDef[] = [
  {
    id: 'frill',
    name: 'フリル',
    title: '星降る町の元気っ子',
    desc: '明るくて好奇心いっぱいの女の子。フリフリのドレスが自慢。いつも笑顔だけど、実はキレると一番怖い！？',
    hp: 100,
    speed: 225,
    power: 3,
    color: '#ff9ec7',
    hairColor: '#ffa8c9',
    dressColor: '#fff6fa',
    accentColor: '#ffd76e',
    unlocked: true,
    skill: FRILL_SKILL,
  },
  {
    id: 'stella',
    name: 'ステラ',
    title: '流れ星の案内人',
    desc: '星空を旅するふしぎな少女。夜ごと新しい星を見つけて記帳している。',
    hp: 90,
    speed: 240,
    power: 2,
    color: '#8fd8ff',
    hairColor: '#a8e0ff',
    dressColor: '#f0f9ff',
    accentColor: '#ffe08a',
    unlocked: false,
    lockReason: '準備中',
    skill: {
      name: '？？？',
      kana: '？？？',
      desc: '準備中です。お楽しみに！',
      cooldown: 10,
    },
  },
  {
    id: 'nova',
    name: 'ノヴァ',
    title: '小さな発明家',
    desc: 'いつも背中のネジ式リュックに新しいギミックを詰め込んでいる天才児。',
    hp: 110,
    speed: 205,
    power: 4,
    color: '#c5a8ff',
    hairColor: '#d3bfff',
    dressColor: '#f6f2ff',
    accentColor: '#8affc1',
    unlocked: false,
    lockReason: '準備中',
    skill: {
      name: '？？？',
      kana: '？？？',
      desc: '準備中です。お楽しみに！',
      cooldown: 14,
    },
  },
  {
    id: 'comet',
    name: 'コメット',
    title: 'おにわの番人',
    desc: '花と星のぴあのを育てる、やさしい見張り番。けっきょくどこでも昼寝してる。',
    hp: 120,
    speed: 195,
    power: 3,
    color: '#ffb37a',
    hairColor: '#ffc79e',
    dressColor: '#fff9f0',
    accentColor: '#a0e8a0',
    unlocked: false,
    lockReason: '準備中',
    skill: {
      name: '？？？',
      kana: '？？？',
      desc: '準備中です。お楽しみに！',
      cooldown: 16,
    },
  },
]

export function getCharacter(id: string): CharacterDef {
  return CHARACTERS.find((c) => c.id === id) ?? CHARACTERS[0]
}
