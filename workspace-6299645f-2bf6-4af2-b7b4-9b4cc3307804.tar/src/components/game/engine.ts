// ===== ゲームエンジン（ロジック＋描画） =====
import type { CharacterDef } from './characters'
import { drawCharacter, drawShadow, drawStar } from './drawAvatar'

export interface HUDState {
  hp: number
  maxHP: number
  score: number
  kills: number
  wave: number
  time: number
  rageCd: number // 0..1（1=使用可能）
  dashCd: number
  rageActive: boolean
  intermission: number // 次のウェーブまでの秒数（0=戦闘中）
}

export interface GameOverResult {
  score: number
  kills: number
  time: number
  wave: number
}

type EnemyKind = 'slime' | 'bat' | 'big'

interface Enemy {
  kind: EnemyKind
  x: number
  y: number
  vx: number
  vy: number
  hp: number
  maxHp: number
  r: number
  speed: number
  dmg: number
  cower: number // ひよってる残り時間（秒）
  hitFlash: number
  wob: number // アニメ位相
  dead: boolean
}

interface Projectile {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  pierce: number
  hitSet: Set<Enemy>
  rot: number
}

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  life: number
  maxLife: number
  size: number
  color: string
  kind: 'star' | 'dot' | 'ring' | 'heart'
  rot: number
  vr: number
}

interface Heart {
  x: number
  y: number
  life: number
}

interface FloatText {
  x: number
  y: number
  text: string
  life: number
  color: string
  size: number
}

interface Deco {
  x: number
  y: number
  kind: 'flower' | 'grass' | 'stone' | 'tree'
  s: number
  hue: number
}

const WORLD_W = 2200
const WORLD_H = 1700
const RAGE_RADIUS = 195
const RAGE_DURATION = 5
const COWER_DURATION = 4
const RAGE_CD = 12
const DASH_CD = 5

function rand(a: number, b: number) {
  return a + Math.random() * (b - a)
}

export class GameEngine {
  private canvas: HTMLCanvasElement
  private ctx: CanvasRenderingContext2D
  private raf = 0
  private running = false
  private paused = false
  private lastT = 0
  private hudAcc = 0
  private dpr = 1
  private viewW = 800
  private viewH = 600

  private ch: CharacterDef
  private onHUD: (h: HUDState) => void
  private onGameOver: (r: GameOverResult) => void

  // 入力（TouchControls / キーボード共用）
  private moveX = 0
  private moveY = 0
  private keyMoveX = 0
  private keyMoveY = 0
  private attacking = false
  private attackTimer = 0

  // プレイヤー
  private px = WORLD_W / 2
  private py = WORLD_H / 2
  private pvx = 0
  private pvy = 0
  private hp: number
  private maxHP: number
  private facing: 1 | -1 = 1
  private invuln = 0
  private dashTime = 0
  private dashCd = 0
  private rageCd = 0
  private rageActive = 0
  private rageCast = 0 // 発動エフェクト用

  // エフェクト
  private shake = 0
  private shakeT = 0

  // 世界
  private enemies: Enemy[] = []
  private projectiles: Projectile[] = []
  private particles: Particle[] = []
  private hearts: Heart[] = []
  private texts: FloatText[] = []
  private decos: Deco[] = []

  private wave = 0
  private waveTimer = 0 // インターミッション残り
  private spawnQueue = 0
  private spawnTimer = 0
  private score = 0
  private kills = 0
  private elapsed = 0
  private noDamageTime = 0
  private gameOverSent = false

  constructor(
    canvas: HTMLCanvasElement,
    opts: {
      character: CharacterDef
      onHUD: (h: HUDState) => void
      onGameOver: (r: GameOverResult) => void
    }
  ) {
    this.canvas = canvas
    this.ctx = canvas.getContext('2d')!
    this.ch = opts.character
    this.onHUD = opts.onHUD
    this.onGameOver = opts.onGameOver
    this.maxHP = opts.character.hp
    this.hp = this.maxHP

    // 装飾物（決定論的に散らす）
    let seed = 12345
    const prand = () => {
      seed = (seed * 1664525 + 1013904223) % 4294967296
      return seed / 4294967296
    }
    for (let i = 0; i < 90; i++) {
      const k = prand()
      this.decos.push({
        x: 60 + prand() * (WORLD_W - 120),
        y: 60 + prand() * (WORLD_H - 120),
        kind: k < 0.5 ? 'flower' : k < 0.8 ? 'grass' : k < 0.94 ? 'stone' : 'tree',
        s: 0.7 + prand() * 0.7,
        hue: prand(),
      })
    }

    this.bindKeys()
    this.resize()
  }

  // ---------- 公開API ----------
  start() {
    if (this.running) return
    this.running = true
    this.lastT = performance.now()
    this.nextWave()
    this.loop(this.lastT)
  }

  destroy() {
    this.running = false
    cancelAnimationFrame(this.raf)
    window.removeEventListener('keydown', this.onKeyDown)
    window.removeEventListener('keyup', this.onKeyUp)
    window.removeEventListener('resize', this.onResize)
  }

  pause() {
    this.paused = true
  }

  resume() {
    if (!this.paused) return
    this.paused = false
    this.lastT = performance.now()
  }

  /** ジョイスティック入力 (-1..1) */
  setMove(x: number, y: number) {
    this.moveX = x
    this.moveY = y
  }

  setAttacking(on: boolean) {
    this.attacking = on
  }

  tryRage() {
    if (this.rageCd > 0 || this.gameOverSent) return
    this.rageCd = RAGE_CD
    this.rageActive = RAGE_DURATION
    this.rageCast = 0.55
    this.addShake(7, 0.35)
    this.texts.push({
      x: this.px,
      y: this.py - 90,
      text: 'フリル・レイジ！',
      life: 1.4,
      color: '#ff5a3c',
      size: 22,
    })
    // 爆発リング
    for (let i = 0; i < 3; i++) {
      this.particles.push({
        x: this.px,
        y: this.py - 20,
        vx: 0,
        vy: 0,
        life: 0.5 + i * 0.16,
        maxLife: 0.5 + i * 0.16,
        size: RAGE_RADIUS * (0.5 + i * 0.22),
        color: i === 0 ? '#ff8a5c' : '#ffd76e',
        kind: 'ring',
        rot: 0,
        vr: 0,
      })
    }
    // 火花
    for (let i = 0; i < 26; i++) {
      const a = rand(0, Math.PI * 2)
      const sp = rand(120, 340)
      this.particles.push({
        x: this.px,
        y: this.py - 20,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 60,
        life: rand(0.4, 0.9),
        maxLife: 0.9,
        size: rand(3, 7),
        color: Math.random() < 0.5 ? '#ff6a4c' : '#ffd76e',
        kind: 'star',
        rot: rand(0, Math.PI * 2),
        vr: rand(-6, 6),
      })
    }
    // 周囲の敵をひよらせる
    for (const e of this.enemies) {
      const dx = e.x - this.px
      const dy = e.y - this.py
      const d = Math.hypot(dx, dy)
      if (d < RAGE_RADIUS + e.r) {
        e.cower = COWER_DURATION
        const n = d > 0.01 ? 1 / d : 0
        // 後ずさり
        e.vx = dx * n * 160
        e.vy = dy * n * 160
      }
    }
  }

  tryDash() {
    if (this.dashCd > 0 || this.gameOverSent) return
    let mx = this.moveX + this.keyMoveX
    let my = this.moveY + this.keyMoveY
    if (Math.abs(mx) < 0.01 && Math.abs(my) < 0.01) {
      mx = this.facing
      my = 0
    }
    const l = Math.hypot(mx, my) || 1
    this.dashTime = 0.18
    this.invuln = Math.max(this.invuln, 0.45)
    this.pvx = (mx / l) * 640
    this.pvy = (my / l) * 640
    this.dashCd = DASH_CD
    for (let i = 0; i < 10; i++) {
      this.particles.push({
        x: this.px,
        y: this.py - 20,
        vx: rand(-60, 60) - (mx / l) * 120,
        vy: rand(-80, 20) - (my / l) * 120,
        life: rand(0.25, 0.5),
        maxLife: 0.5,
        size: rand(2.5, 5),
        color: '#cdefff',
        kind: 'dot',
        rot: 0,
        vr: 0,
      })
    }
  }

  // ---------- 内部 ----------
  private addShake(mag: number, dur: number) {
    this.shake = Math.max(this.shake, mag)
    this.shakeT = Math.max(this.shakeT, dur)
  }

  private nextWave() {
    this.wave++
    this.spawnQueue = 3 + this.wave * 2
    this.spawnTimer = 0.4
    this.texts.push({
      x: this.px,
      y: this.py - 110,
      text: `Wave ${this.wave}`,
      life: 1.6,
      color: '#ffffff',
      size: 26,
    })
  }

  private spawnEnemy() {
    const w = this.wave
    let kind: EnemyKind = 'slime'
    const roll = Math.random()
    if (w >= 2 && roll < 0.3) kind = 'bat'
    if (w >= 3 && roll > 0.86) kind = 'big'
    // プレイヤーから離れた枠周辺に出現
    let x = 0
    let y = 0
    for (let tries = 0; tries < 20; tries++) {
      const side = Math.floor(rand(0, 4))
      if (side === 0) {
        x = rand(40, WORLD_W - 40)
        y = 40
      } else if (side === 1) {
        x = rand(40, WORLD_W - 40)
        y = WORLD_H - 40
      } else if (side === 2) {
        x = 40
        y = rand(40, WORLD_H - 40)
      } else {
        x = WORLD_W - 40
        y = rand(40, WORLD_H - 40)
      }
      if (Math.hypot(x - this.px, y - this.py) > 420) break
    }
    const base: Record<EnemyKind, { hp: number; r: number; sp: number; dmg: number }> = {
      slime: { hp: 3, r: 17, sp: 66, dmg: 7 },
      bat: { hp: 2, r: 14, sp: 120, dmg: 5 },
      big: { hp: 9, r: 26, sp: 48, dmg: 12 },
    }
    const b = base[kind]
    const hpScale = 1 + (w - 1) * 0.22
    this.enemies.push({
      kind,
      x,
      y,
      vx: 0,
      vy: 0,
      hp: Math.ceil(b.hp * hpScale),
      maxHp: Math.ceil(b.hp * hpScale),
      r: b.r,
      speed: b.sp + (w - 1) * 4,
      dmg: b.dmg,
      cower: 0,
      hitFlash: 0,
      wob: rand(0, Math.PI * 2),
      dead: false,
    })
  }

  private shoot() {
    // 最も近い敵へ自動照準、いなければ向いてる方向
    let tx = this.px + this.facing * 100
    let ty = this.py - 20
    let best = 520
    for (const e of this.enemies) {
      const d = Math.hypot(e.x - this.px, e.y - (this.py - 20))
      if (d < best) {
        best = d
        tx = e.x
        ty = e.y - e.r
      }
    }
    const a = Math.atan2(ty - (this.py - 24), tx - this.px)
    const sp = 470
    this.projectiles.push({
      x: this.px + Math.cos(a) * 14,
      y: this.py - 24 + Math.sin(a) * 14,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: 1.25,
      pierce: this.rageActive > 0 ? 1 : 0,
      hitSet: new Set(),
      rot: a,
    })
  }

  private hurtPlayer(dmg: number, fromX: number, fromY: number) {
    if (this.invuln > 0 || this.gameOverSent) return
    this.hp = Math.max(0, this.hp - dmg)
    this.invuln = 1.1
    this.noDamageTime = 0
    const dx = this.px - fromX
    const dy = this.py - fromY
    const d = Math.hypot(dx, dy) || 1
    this.pvx = (dx / d) * 190
    this.pvy = (dy / d) * 190
    this.addShake(5, 0.25)
    this.texts.push({
      x: this.px,
      y: this.py - 80,
      text: `-${dmg}`,
      life: 0.8,
      color: '#ff5a5a',
      size: 16,
    })
    if (this.hp <= 0) {
      this.gameOverSent = true
      this.onGameOver({ score: this.score, kills: this.kills, time: this.elapsed, wave: this.wave })
    }
  }

  private update(dt: number) {
    this.elapsed += dt

    // 一定時間無傷ならゆっくり回復（やさしいバランス）
    this.noDamageTime += dt
    if (this.noDamageTime > 4 && this.hp < this.maxHP) {
      this.hp = Math.min(this.maxHP, this.hp + 3 * dt)
    }

    // ---- インターミッション / 湧き ----
    if (this.spawnQueue > 0) {
      this.spawnTimer -= dt
      if (this.spawnTimer <= 0) {
        this.spawnEnemy()
        this.spawnQueue--
        this.spawnTimer = Math.max(0.18, 0.7 - this.wave * 0.04)
      }
    } else if (this.enemies.length === 0) {
      if (this.waveTimer <= 0) this.waveTimer = 2.2
      this.waveTimer -= dt
      if (this.waveTimer <= 0) {
        this.waveTimer = 0
        this.score += 50 * this.wave
        this.nextWave()
      }
    }

    // ---- クールダウン ----
    this.rageCd = Math.max(0, this.rageCd - dt)
    this.dashCd = Math.max(0, this.dashCd - dt)
    this.rageActive = Math.max(0, this.rageActive - dt)
    this.rageCast = Math.max(0, this.rageCast - dt)
    this.invuln = Math.max(0, this.invuln - dt)
    this.shakeT = Math.max(0, this.shakeT - dt)
    if (this.shakeT <= 0) this.shake = 0

    // ---- プレイヤー移動 ----
    let mx = this.moveX + this.keyMoveX
    let my = this.moveY + this.keyMoveY
    const ml = Math.hypot(mx, my)
    if (ml > 1) {
      mx /= ml
      my /= ml
    }
    if (this.dashTime > 0) {
      this.dashTime -= dt
      // ダッシュ中は慣性のまま
    } else {
      const speed = this.ch.speed * (this.rageActive > 0 ? 1.22 : 1)
      this.pvx = mx * speed
      this.pvy = my * speed
    }
    if (Math.abs(this.pvx) > 4) this.facing = this.pvx > 0 ? 1 : -1
    this.px = Math.min(WORLD_W - 26, Math.max(26, this.px + this.pvx * dt))
    this.py = Math.min(WORLD_H - 22, Math.max(22, this.py + this.pvy * dt))

    // ---- 攻撃 ----
    this.attackTimer -= dt
    if ((this.attacking || this.keys.attack) && this.attackTimer <= 0) {
      this.shoot()
      this.attackTimer = this.rageActive > 0 ? 0.26 : 0.34
    }

    // ---- 敵 ----
    for (const e of this.enemies) {
      e.wob += dt * (e.kind === 'bat' ? 9 : 5)
      e.hitFlash = Math.max(0, e.hitFlash - dt * 6)
      if (e.cower > 0) {
        e.cower -= dt
        // 後ずさりは減衰、その後その場で震える
        e.vx *= Math.pow(0.02, dt)
        e.vy *= Math.pow(0.02, dt)
        e.x += e.vx * dt
        e.y += e.vy * dt
        continue
      }
      const dx = this.px - e.x
      const dy = this.py - e.y
      const d = Math.hypot(dx, dy) || 1
      // 分離（重なり防止）
      let sx = 0
      let sy = 0
      for (const o of this.enemies) {
        if (o === e) continue
        const ox = e.x - o.x
        const oy = e.y - o.y
        const od = Math.hypot(ox, oy)
        const min = e.r + o.r
        if (od > 0.01 && od < min) {
          sx += (ox / od) * (min - od) * 2.2
          sy += (oy / od) * (min - od) * 2.2
        }
      }
      e.vx = (dx / d) * e.speed + sx
      e.vy = (dy / d) * e.speed + sy
      e.x += e.vx * dt
      e.y += e.vy * dt
      // 接触ダメージ
      if (d < e.r + 16) {
        this.hurtPlayer(e.dmg, e.x, e.y)
      }
    }
    this.enemies = this.enemies.filter((e) => !e.dead)

    // ---- 弾 ----
    for (const p of this.projectiles) {
      p.life -= dt
      p.x += p.vx * dt
      p.y += p.vy * dt
      p.rot += dt * 12
      for (const e of this.enemies) {
        if (e.dead) continue
        if (p.hitSet.has(e)) continue
        if (Math.hypot(e.x - p.x, e.y - p.y) < e.r + 8) {
          p.hitSet.add(e)
          e.hp -= 1
          e.hitFlash = 1
          if (e.hp <= 0) {
            e.dead = true
            this.kills++
            const pts = e.kind === 'big' ? 30 : e.kind === 'bat' ? 15 : 10
            this.score += pts
            this.texts.push({
              x: e.x,
              y: e.y - 26,
              text: `+${pts}`,
              life: 0.9,
              color: '#ffd76e',
              size: 15,
            })
            // 消滅パーティクル
            for (let i = 0; i < 8; i++) {
              const a = rand(0, Math.PI * 2)
              this.particles.push({
                x: e.x,
                y: e.y - e.r * 0.5,
                vx: Math.cos(a) * rand(40, 160),
                vy: Math.sin(a) * rand(40, 160) - 40,
                life: rand(0.3, 0.6),
                maxLife: 0.6,
                size: rand(2, 4.5),
                color: e.kind === 'bat' ? '#c5a8ff' : '#8fe0a8',
                kind: 'dot',
                rot: 0,
                vr: 0,
              })
            }
            // ハートドロップ
            if (Math.random() < 0.15) {
              this.hearts.push({ x: e.x, y: e.y, life: 10 })
            }
          }
          if (p.pierce > 0) p.pierce--
          else p.life = 0
        }
      }
    }
    this.projectiles = this.projectiles.filter((p) => p.life > 0)

    // ---- ハート ----
    for (const h of this.hearts) {
      h.life -= dt
      if (Math.hypot(h.x - this.px, h.y - this.py) < 26 && this.hp < this.maxHP) {
        h.life = 0
        this.hp = Math.min(this.maxHP, this.hp + 20)
        this.texts.push({
          x: this.px,
          y: this.py - 80,
          text: '+20 ♥',
          life: 0.9,
          color: '#ff9ec7',
          size: 16,
        })
      }
    }
    this.hearts = this.hearts.filter((h) => h.life > 0)

    // ---- パーティクル・テキスト ----
    for (const p of this.particles) {
      p.life -= dt
      if (p.kind !== 'ring') {
        p.x += p.vx * dt
        p.y += p.vy * dt
        p.vy += 260 * dt
        p.rot += p.vr * dt
      }
    }
    this.particles = this.particles.filter((p) => p.life > 0)
    for (const t of this.texts) {
      t.life -= dt
      t.y -= 26 * dt
    }
    this.texts = this.texts.filter((t) => t.life > 0)
  }

  // ---------- 描画 ----------
  private render() {
    const ctx = this.ctx
    const { width, height } = this.canvas
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0)
    ctx.clearRect(0, 0, this.viewW, this.viewH)

    // カメラ
    let camX = this.px - this.viewW / 2
    let camY = this.py - this.viewH / 2
    camX = Math.min(WORLD_W - this.viewW, Math.max(0, camX))
    camY = Math.min(WORLD_H - this.viewH, Math.max(0, camY))
    if (this.viewW > WORLD_W) camX = (WORLD_W - this.viewW) / 2
    if (this.viewH > WORLD_H) camY = (WORLD_H - this.viewH) / 2
    if (this.shake > 0) {
      camX += rand(-this.shake, this.shake)
      camY += rand(-this.shake, this.shake)
    }

    ctx.save()
    ctx.translate(-camX, -camY)

    // 地面（パステルチェック）
    const tile = 100
    const x0 = Math.max(0, Math.floor(camX / tile) * tile)
    const y0 = Math.max(0, Math.floor(camY / tile) * tile)
    for (let gy = y0; gy < Math.min(WORLD_H, camY + this.viewH + tile); gy += tile) {
      for (let gx = x0; gx < Math.min(WORLD_W, camX + this.viewW + tile); gx += tile) {
        const odd = ((gx / tile + gy / tile) | 0) % 2 === 0
        ctx.fillStyle = odd ? '#bfe8b4' : '#b4e0ac'
        ctx.fillRect(gx, gy, tile, tile)
      }
    }
    // 外枠（世界の境界）
    ctx.strokeStyle = 'rgba(90, 60, 40, 0.55)'
    ctx.lineWidth = 12
    ctx.strokeRect(6, 6, WORLD_W - 12, WORLD_H - 12)

    // 装飾
    for (const d of this.decos) {
      this.drawDeco(d)
    }

    // ハート
    for (const h of this.hearts) {
      const bob = Math.sin(this.elapsed * 5 + h.x) * 4
      ctx.save()
      ctx.globalAlpha = h.life < 2 ? 0.4 + 0.6 * Math.abs(Math.sin(h.life * 6)) : 1
      ctx.font = '20px system-ui'
      ctx.textAlign = 'center'
      ctx.fillText('💖', h.x, h.y - 10 + bob)
      ctx.restore()
    }

    // 怒り範囲の予兆リング（詠唱中）
    if (this.rageCast > 0) {
      const pr = RAGE_RADIUS * (1 - this.rageCast / 0.55)
      ctx.strokeStyle = `rgba(255, 90, 60, ${0.75 * (this.rageCast / 0.55)})`
      ctx.lineWidth = 5
      ctx.beginPath()
      ctx.arc(this.px, this.py - 10, pr, 0, Math.PI * 2)
      ctx.stroke()
    }

    // 敵
    for (const e of this.enemies) this.drawEnemy(e)

    // 弾
    for (const p of this.projectiles) {
      drawStar(ctx, p.x, p.y, 8, '#ffe08a', p.rot)
      ctx.save()
      ctx.globalAlpha = 0.35
      drawStar(ctx, p.x, p.y, 11, '#ffd76e', p.rot * 0.7)
      ctx.restore()
    }

    // パーティクル
    for (const p of this.particles) {
      const a = Math.max(0, p.life / p.maxLife)
      ctx.save()
      ctx.globalAlpha = a
      if (p.kind === 'ring') {
        ctx.strokeStyle = p.color
        ctx.lineWidth = 6 * a
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size * (1 - a) + 12, 0, Math.PI * 2)
        ctx.stroke()
      } else if (p.kind === 'star') {
        drawStar(ctx, p.x, p.y, p.size, p.color, p.rot)
      } else {
        ctx.fillStyle = p.color
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.restore()
    }

    // フリル
    const blink = this.invuln > 0 && Math.floor(this.elapsed * 14) % 2 === 0
    if (!blink) {
      drawCharacter(ctx, this.ch, this.px, this.py, 1, {
        time: this.elapsed,
        moving: Math.hypot(this.pvx, this.pvy) > 20,
        facing: this.facing,
        rage: this.rageActive > 0 || this.rageCast > 0,
        hurt: this.invuln > 0,
      })
    }

    // 浮遊テキスト
    for (const t of this.texts) {
      ctx.save()
      ctx.globalAlpha = Math.min(1, t.life * 2)
      ctx.font = `bold ${t.size}px ui-rounded, system-ui, sans-serif`
      ctx.textAlign = 'center'
      ctx.strokeStyle = 'rgba(40, 20, 40, 0.7)'
      ctx.lineWidth = 3.5
      ctx.strokeText(t.text, t.x, t.y)
      ctx.fillStyle = t.color
      ctx.fillText(t.text, t.x, t.y)
      ctx.restore()
    }

    ctx.restore()
  }

  private drawDeco(d: Deco) {
    const ctx = this.ctx
    if (d.kind === 'flower') {
      const cols = ['#ff9ec7', '#ffd76e', '#ffffff', '#c5a8ff']
      ctx.fillStyle = cols[Math.floor(d.hue * cols.length)]
      for (let i = 0; i < 4; i++) {
        const a = (i * Math.PI) / 2 + d.hue * 3
        ctx.beginPath()
        ctx.arc(d.x + Math.cos(a) * 3 * d.s, d.y + Math.sin(a) * 3 * d.s, 2.1 * d.s, 0, Math.PI * 2)
        ctx.fill()
      }
      ctx.fillStyle = '#ffe08a'
      ctx.beginPath()
      ctx.arc(d.x, d.y, 1.4 * d.s, 0, Math.PI * 2)
      ctx.fill()
    } else if (d.kind === 'grass') {
      ctx.strokeStyle = 'rgba(90, 160, 90, 0.6)'
      ctx.lineWidth = 1.6
      ctx.beginPath()
      ctx.moveTo(d.x - 3 * d.s, d.y)
      ctx.quadraticCurveTo(d.x - 4 * d.s, d.y - 5 * d.s, d.x - 2 * d.s, d.y - 7 * d.s)
      ctx.moveTo(d.x, d.y)
      ctx.lineTo(d.x, d.y - 8 * d.s)
      ctx.moveTo(d.x + 3 * d.s, d.y)
      ctx.quadraticCurveTo(d.x + 4 * d.s, d.y - 5 * d.s, d.x + 2 * d.s, d.y - 7 * d.s)
      ctx.stroke()
    } else if (d.kind === 'stone') {
      ctx.fillStyle = 'rgba(150, 150, 160, 0.5)'
      ctx.beginPath()
      ctx.ellipse(d.x, d.y, 5 * d.s, 3.4 * d.s, 0, 0, Math.PI * 2)
      ctx.fill()
    } else {
      // 木
      ctx.fillStyle = '#8a5a44'
      ctx.fillRect(d.x - 2.4 * d.s, d.y - 14 * d.s, 4.8 * d.s, 14 * d.s)
      ctx.fillStyle = d.hue > 0.5 ? '#79c47f' : '#8fd494'
      ctx.beginPath()
      ctx.arc(d.x, d.y - 20 * d.s, 11 * d.s, 0, Math.PI * 2)
      ctx.arc(d.x - 8 * d.s, d.y - 14 * d.s, 7.5 * d.s, 0, Math.PI * 2)
      ctx.arc(d.x + 8 * d.s, d.y - 14 * d.s, 7.5 * d.s, 0, Math.PI * 2)
      ctx.fill()
    }
  }

  private drawEnemy(e: Enemy) {
    const ctx = this.ctx
    const shakeX = e.cower > 0 ? Math.sin(this.elapsed * 34) * 2.4 : 0
    const yOff = e.kind === 'bat' ? -12 + Math.sin(e.wob) * 4 : -Math.abs(Math.sin(e.wob)) * 4

    drawShadow(ctx, e.x, e.y, e.r * 0.9)

    ctx.save()
    ctx.translate(e.x + shakeX, e.y + yOff)

    // ひよってる演出：青みがかった色＋汗
    const cower = e.cower > 0
    const body = (c1: string) => (cower ? '#9db8e8' : e.hitFlash > 0.4 ? '#ffffff' : c1)

    if (e.kind === 'bat') {
      // 羽
      ctx.fillStyle = cower ? '#8fa8d8' : '#b39ddb'
      const flap = Math.sin(e.wob) * 0.5
      for (const s of [-1, 1]) {
        ctx.save()
        ctx.rotate(s * flap)
        ctx.beginPath()
        ctx.ellipse(s * 13, -6, 10, 4.6, s * 0.5, 0, Math.PI * 2)
        ctx.fill()
        ctx.restore()
      }
      // 体
      ctx.fillStyle = body('#a58ad8')
      ctx.beginPath()
      ctx.arc(0, -8, 10, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = '#fff'
      ctx.beginPath()
      ctx.arc(-3.4, -10, 2.4, 0, Math.PI * 2)
      ctx.arc(3.4, -10, 2.4, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = '#333'
      ctx.beginPath()
      ctx.arc(-3.4, -10, 1.1, 0, Math.PI * 2)
      ctx.arc(3.4, -10, 1.1, 0, Math.PI * 2)
      ctx.fill()
    } else {
      // スライム（big / slime）
      const big = e.kind === 'big'
      const sq = 1 + Math.sin(e.wob) * 0.07
      const r = e.r
      ctx.fillStyle = body(big ? '#4caf7d' : '#7fd8a0')
      ctx.beginPath()
      ctx.ellipse(0, -r * 0.55 * sq, r * (2 - sq) * 0.62, r * 0.62 * sq, 0, 0, Math.PI * 2)
      ctx.fill()
      // ハイライト
      ctx.fillStyle = 'rgba(255,255,255,0.5)'
      ctx.beginPath()
      ctx.arc(-r * 0.24, -r * 0.85 * sq, r * 0.16, 0, Math.PI * 2)
      ctx.fill()
      // 目
      ctx.fillStyle = '#fff'
      ctx.beginPath()
      ctx.arc(-r * 0.22, -r * 0.6, r * 0.17, 0, Math.PI * 2)
      ctx.arc(r * 0.22, -r * 0.6, r * 0.17, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = '#333'
      const eyeH = cower ? r * 0.03 : r * 0.09
      ctx.beginPath()
      ctx.ellipse(-r * 0.22, -r * 0.6, r * 0.08, eyeH + r * 0.05, 0, 0, Math.PI * 2)
      ctx.ellipse(r * 0.22, -r * 0.6, r * 0.08, eyeH + r * 0.05, 0, 0, Math.PI * 2)
      ctx.fill()
    }

    // ひよってる印：ビクッ記号＋汗
    if (cower) {
      ctx.fillStyle = '#ffffff'
      ctx.strokeStyle = '#5a78b8'
      ctx.lineWidth = 1.4
      ctx.font = `bold ${Math.max(11, e.r * 0.7)}px system-ui`
      ctx.textAlign = 'center'
      ctx.fillText('!', 0, -e.r - 10 + Math.sin(this.elapsed * 10) * 1.5)
      // 汗しずく
      ctx.fillStyle = '#9fd8ff'
      ctx.beginPath()
      ctx.ellipse(e.r * 0.8, -e.r - 4, 2.2, 3.2, 0.3, 0, Math.PI * 2)
      ctx.fill()
    }

    ctx.restore()
  }

  // ---------- ループ ----------
  private loop = (t: number) => {
    if (!this.running) return
    this.raf = requestAnimationFrame(this.loop)
    const dt = Math.min(0.05, (t - this.lastT) / 1000)
    this.lastT = t
    if (!this.paused && !this.gameOverSent) {
      this.update(dt)
    }
    this.render()

    // HUD同期（15Hzに制限）
    this.hudAcc += dt
    if (this.hudAcc > 1 / 15) {
      this.hudAcc = 0
      this.onHUD({
        hp: this.hp,
        maxHP: this.maxHP,
        score: this.score,
        kills: this.kills,
        wave: this.wave,
        time: this.elapsed,
        rageCd: 1 - this.rageCd / RAGE_CD,
        dashCd: 1 - this.dashCd / DASH_CD,
        rageActive: this.rageActive > 0,
        intermission: this.enemies.length === 0 && this.spawnQueue === 0 ? Math.max(0, this.waveTimer) : 0,
      })
    }
  }

  private resize = () => {
    const rect = this.canvas.getBoundingClientRect()
    this.dpr = Math.min(2, window.devicePixelRatio || 1)
    this.viewW = Math.max(1, Math.round(rect.width))
    this.viewH = Math.max(1, Math.round(rect.height))
    this.canvas.width = Math.round(this.viewW * this.dpr)
    this.canvas.height = Math.round(this.viewH * this.dpr)
  }

  private onResize = () => this.resize()

  private bindKeys() {
    window.addEventListener('keydown', this.onKeyDown)
    window.addEventListener('keyup', this.onKeyUp)
    window.addEventListener('resize', this.onResize)
  }

  private keys = { attack: false }

  private onKeyDown = (e: KeyboardEvent) => {
    // e.code が空の環境（一部の仮想キーボード・自動テスト）では e.key にフォールバック
    const code = e.code || e.key
    switch (code) {
      case 'ArrowLeft':
      case 'KeyA':
      case 'a':
      case 'A':
        this.keyMoveX = -1
        break
      case 'ArrowRight':
      case 'KeyD':
      case 'd':
      case 'D':
        this.keyMoveX = 1
        break
      case 'ArrowUp':
      case 'KeyW':
      case 'w':
      case 'W':
        this.keyMoveY = -1
        break
      case 'ArrowDown':
      case 'KeyS':
      case 's':
      case 'S':
        this.keyMoveY = 1
        break
      case 'KeyJ':
      case 'Space':
      case 'j':
      case 'J':
      case ' ':
        this.keys.attack = true
        break
      case 'KeyK':
      case 'k':
      case 'K':
        this.tryRage()
        break
      case 'KeyL':
      case 'ShiftLeft':
      case 'l':
      case 'L':
        this.tryDash()
        break
    }
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space', ' '].includes(code as string)) {
      e.preventDefault()
    }
  }

  private onKeyUp = (e: KeyboardEvent) => {
    const code = e.code || e.key
    switch (code) {
      case 'ArrowLeft':
      case 'KeyA':
      case 'a':
      case 'A':
        if (this.keyMoveX < 0) this.keyMoveX = 0
        break
      case 'ArrowRight':
      case 'KeyD':
      case 'd':
      case 'D':
        if (this.keyMoveX > 0) this.keyMoveX = 0
        break
      case 'ArrowUp':
      case 'KeyW':
      case 'w':
      case 'W':
        if (this.keyMoveY < 0) this.keyMoveY = 0
        break
      case 'ArrowDown':
      case 'KeyS':
      case 's':
      case 'S':
        if (this.keyMoveY > 0) this.keyMoveY = 0
        break
      case 'KeyJ':
      case 'Space':
      case 'j':
      case 'J':
      case ' ':
        this.keys.attack = false
        break
    }
  }
}
