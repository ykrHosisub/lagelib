'use client'

// ===== キャラ一覧：スマホは1列フルワイド／デスクトップはグリッド =====
import { ChevronLeft, Lock, Star, Gauge, Swords, Zap } from 'lucide-react'
import { CHARACTERS, type CharacterDef } from './characters'
import { drawCharacter } from './drawAvatar'
import { useEffect, useRef } from 'react'

function Portrait({ ch, size = 96, rage = false }: { ch: CharacterDef; size?: number; rage?: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    canvas.width = size * dpr
    canvas.height = size * dpr
    canvas.style.width = `${size}px`
    canvas.style.height = `${size}px`
    let raf = 0
    const t0 = performance.now()
    const draw = (t: number) => {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, size, size)
      drawCharacter(ctx, ch, size / 2, size - 10, size / 110, {
        time: (t - t0) / 1000,
        moving: false,
        facing: 1,
        rage,
        hurt: false,
      })
      raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [ch, size, rage])
  return <canvas ref={ref} />
}

function StatBar({ icon, label, value, max, color }: { icon: React.ReactNode; label: string; value: number; max: number; color: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="flex w-12 items-center gap-1 text-[10px] text-white/60">
        {icon}
        {label}
      </span>
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
        <div className="h-full rounded-full" style={{ width: `${(value / max) * 100}%`, background: color }} />
      </div>
    </div>
  )
}

function CharacterCard({
  ch,
  selected,
  isMobile,
  onSelect,
}: {
  ch: CharacterDef
  selected: boolean
  isMobile: boolean
  onSelect: () => void
}) {
  const locked = !ch.unlocked
  return (
    <button
      type="button"
      disabled={locked}
      onPointerDown={(e) => {
        e.preventDefault()
        if (!locked) onSelect()
      }}
      className={`game-scrollable relative w-full overflow-hidden rounded-2xl border-2 text-left transition-all active:scale-[0.98] ${
        locked
          ? 'border-white/10 bg-black/30 opacity-60'
          : selected
            ? 'border-amber-300 bg-white/12 shadow-lg shadow-amber-300/10'
            : 'border-white/15 bg-white/[0.06] hover:bg-white/10'
      } ${isMobile ? 'p-4' : 'p-5'}`}
    >
      {/* 選択バッジ */}
      {selected && !locked && (
        <div className="absolute right-3 top-3 rounded-full bg-amber-300 px-2.5 py-0.5 text-[10px] font-extrabold text-[#4a2c00]">
          選択中
        </div>
      )}
      {locked && (
        <div className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-black/50 px-2.5 py-0.5 text-[10px] font-bold text-white/60">
          <Lock size={10} />
          {ch.lockReason}
        </div>
      )}

      <div className="flex items-center gap-3">
        <div
          className="flex shrink-0 items-end justify-center rounded-xl"
          style={{
            width: isMobile ? 84 : 96,
            height: isMobile ? 84 : 96,
            background: `radial-gradient(circle at 50% 85%, ${ch.color}30, transparent 70%)`,
          }}
        >
          <Portrait ch={ch} size={isMobile ? 84 : 96} />
        </div>
        <div className="min-w-0 flex-1">
          <div className={`font-extrabold text-white ${isMobile ? 'text-lg' : 'text-xl'}`}>
            {ch.name}
            <span className="ml-2 text-[11px] font-medium text-white/55">{ch.title}</span>
          </div>
          <p className={`mt-1 leading-snug text-white/65 ${isMobile ? 'line-clamp-2 text-[11px]' : 'text-xs'}`}>
            {ch.desc}
          </p>
          {!locked && (
            <div className={`mt-2 space-y-1 ${isMobile ? 'max-w-[210px]' : 'max-w-[240px]'}`}>
              <StatBar icon={<Star size={10} />} label="HP" value={ch.hp} max={130} color="#4ade80" />
              <StatBar icon={<Gauge size={10} />} label="速さ" value={ch.speed} max={250} color="#60a5fa" />
              <StatBar icon={<Swords size={10} />} label="力" value={ch.power} max={5} color="#f87171" />
            </div>
          )}
        </div>
      </div>

      {/* スキル */}
      <div className={`mt-3 rounded-xl bg-black/25 ${isMobile ? 'p-2.5' : 'p-3'}`}>
        <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-200">
          <Zap size={12} />
          スキル：{ch.skill.name}
          {!locked && <span className="ml-auto text-[10px] font-medium text-white/45">CT {ch.skill.cooldown}s</span>}
        </div>
        <p className={`mt-1 leading-snug text-white/60 ${isMobile ? 'text-[10px]' : 'text-[11px]'}`}>
          {locked ? '準備中です。お楽しみに！' : ch.skill.desc}
        </p>
      </div>
    </button>
  )
}

export default function CharacterSelect({
  isMobile,
  selectedId,
  onSelect,
  onBack,
  onStart,
}: {
  isMobile: boolean
  selectedId: string
  onSelect: (id: string) => void
  onBack: () => void
  onStart: (ch: CharacterDef) => void
}) {
  const selected = CHARACTERS.find((c) => c.id === selectedId) ?? CHARACTERS[0]
  const canStart = selected.unlocked

  return (
    <div className="game-root fixed inset-0 flex flex-col overflow-hidden bg-gradient-to-b from-[#241a4d] via-[#1a1030] to-[#120a20]">
      <div className="hn-starfield pointer-events-none absolute inset-0 opacity-50" />

      {/* ヘッダー */}
      <header
        className="relative z-10 flex items-center gap-2 border-b border-white/10 bg-black/25 backdrop-blur-sm"
        style={{ paddingTop: 'env(safe-area-inset-top)' }}
      >
        <button
          type="button"
          aria-label="戻る"
          onPointerDown={(e) => {
            e.preventDefault()
            onBack()
          }}
          className={`flex items-center justify-center rounded-full text-white/85 active:scale-90 ${
            isMobile ? 'm-2 h-10 w-10' : 'm-3 h-11 w-11 hover:bg-white/10'
          }`}
        >
          <ChevronLeft size={isMobile ? 22 : 24} />
        </button>
        <h1 className={`font-extrabold text-white ${isMobile ? 'text-lg' : 'text-xl'}`}>キャラ一覧</h1>
        {!isMobile && (
          <span className="ml-3 text-xs text-white/45">キャラを選んでプレイしよう！</span>
        )}
      </header>

      {/* リスト（スマホ：1列・大きめタッチ領域） */}
      <div
        className={`game-scrollable relative z-10 flex-1 overflow-y-auto ${
          isMobile ? 'px-3 py-3' : 'px-6 py-6'
        }`}
        style={{ paddingBottom: isMobile ? 'calc(96px + env(safe-area-inset-bottom))' : '24px' }}
      >
        <div className={isMobile ? 'flex flex-col gap-3' : 'mx-auto grid max-w-4xl grid-cols-2 gap-4'}>
          {CHARACTERS.map((ch) => (
            <CharacterCard
              key={ch.id}
              ch={ch}
              isMobile={isMobile}
              selected={ch.id === selectedId}
              onSelect={() => onSelect(ch.id)}
            />
          ))}
        </div>
      </div>

      {/* スタートバー（スマホは固定・大きめボタン） */}
      <div
        className="relative z-10 border-t border-white/10 bg-black/40 backdrop-blur-md"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className={`flex items-center gap-3 ${isMobile ? 'px-4 py-3' : 'mx-auto max-w-4xl px-6 py-4'}`}>
          <div className="hidden sm:block">
            <Portrait ch={selected} size={56} />
          </div>
          <div className="min-w-0 flex-1">
            <div className={`font-bold text-white ${isMobile ? 'text-base' : 'text-lg'}`}>
              {selected.name}
              <span className="ml-2 text-xs font-medium text-white/50">{selected.title}</span>
            </div>
            <div className="truncate text-[11px] text-white/50">
              スキル：{selected.skill.name}
            </div>
          </div>
          <button
            type="button"
            disabled={!canStart}
            onPointerDown={(e) => {
              e.preventDefault()
              if (canStart) onStart(selected)
            }}
            className={`shrink-0 rounded-xl font-extrabold transition-transform active:scale-95 ${
              canStart
                ? 'bg-gradient-to-r from-pink-500 via-rose-400 to-orange-400 text-white shadow-lg shadow-pink-500/25'
                : 'cursor-not-allowed bg-white/10 text-white/35'
            } ${isMobile ? 'px-8 py-4 text-base' : 'px-7 py-3.5 text-sm'}`}
          >
            {canStart ? 'このキャラでプレイ' : '準備中'}
          </button>
        </div>
      </div>

      {/* コピーライト */}
      <div
        className="pointer-events-none absolute bottom-1 right-3 z-20 select-none text-[10px] font-semibold text-white/40"
      >
        ©🌟HoshiNet
      </div>
    </div>
  )
}
