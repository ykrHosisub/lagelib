'use client'

// ===== アプリ本体：HoshiNetスプラッシュ → タイトル → キャラ一覧 → ゲーム =====
import { useEffect, useState, useCallback } from 'react'
import { getCharacter, type CharacterDef } from './characters'
import SplashScreen from './SplashScreen'
import TitleScreen from './TitleScreen'
import CharacterSelect from './CharacterSelect'
import GameScreen from './GameScreen'

type Phase = 'splash' | 'title' | 'select' | 'game'

/** スマホ判定：タッチが主入力のデバイス、もしくは狭い画面幅のときモバイルUIにする */
function useIsMobile(): boolean {
  const [mobile, setMobile] = useState(false)
  useEffect(() => {
    const coarse = window.matchMedia('(pointer: coarse)')
    const small = window.matchMedia('(max-width: 820px)')
    const check = () => setMobile(coarse.matches || small.matches)
    check()
    coarse.addEventListener?.('change', check)
    small.addEventListener?.('change', check)
    return () => {
      coarse.removeEventListener?.('change', check)
      small.removeEventListener?.('change', check)
    }
  }, [])
  return mobile
}

export default function GameApp() {
  const [phase, setPhase] = useState<Phase>('splash')
  const [charId, setCharId] = useState('frill')
  const [gameKey, setGameKey] = useState(0)
  const isMobile = useIsMobile()

  const startGame = useCallback((c: CharacterDef) => {
    setCharId(c.id)
    setGameKey((k) => k + 1)
    setPhase('game')
  }, [])

  return (
    <div className="hn-host fixed inset-0 overflow-hidden bg-[#1a1030] font-sans">
      {phase === 'splash' && <SplashScreen onDone={() => setPhase('title')} />}

      {phase === 'title' && <TitleScreen isMobile={isMobile} onPlay={() => setPhase('select')} />}

      {phase === 'select' && (
        <CharacterSelect
          isMobile={isMobile}
          selectedId={charId}
          onSelect={setCharId}
          onBack={() => setPhase('title')}
          onStart={startGame}
        />
      )}

      {phase === 'game' && (
        <GameScreen
          key={gameKey}
          character={getCharacter(charId)}
          isMobile={isMobile}
          onQuit={() => setPhase('title')}
          onRestart={() => setGameKey((k) => k + 1)}
        />
      )}
    </div>
  )
}
