'use client'

// ===== タイトル画面：プレイボタン＋右下 ©🌟HoshiNet =====
import { Play, Users } from 'lucide-react'
import { drawCharacter } from './drawAvatar'
import { getCharacter } from './characters'
import { useEffect, useRef } from 'react'

export default function TitleScreen({
  isMobile,
  onPlay,
}: {
  isMobile: boolean
  onPlay: () => void
}) {
  // タイトルにフリルの立ち絵を描く
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')!
    const dpr = Math.min(2, window.devicePixelRatio || 1)
    const w = 200
    const h = 200
    canvas.width = w * dpr
    canvas.height = h * dpr
    canvas.style.width = `${w}px`
    canvas.style.height = `${h}px`
    let raf = 0
    const ch = getCharacter('frill')
    const t0 = performance.now()
    const draw = (t: number) => {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, w, h)
      drawCharacter(ctx, ch, w / 2, h - 28, 2.0, {
        time: (t - t0) / 1000,
        moving: false,
        facing: 1,
        rage: false,
        hurt: false,
      })
      raf = requestAnimationFrame(draw)
    }
    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <div className="game-root fixed inset-0 overflow-hidden bg-gradient-to-b from-[#241a4d] via-[#1a1030] to-[#120a20]">
      {/* 星空 */}
      <div className="hn-starfield pointer-events-none absolute inset-0 opacity-80" />
      {/* 地平線の光 */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-pink-500/15 to-transparent" />

      <div className="relative flex h-full flex-col items-center justify-center px-6">
        {/* ロゴ */}
        <div className="hn-fade-in text-center">
          <div className="mb-1 text-xs font-semibold uppercase tracking-[0.4em] text-amber-200/70">
            HoshiNet presents
          </div>
          <h1 className="bg-gradient-to-b from-white via-amber-100 to-amber-300 bg-clip-text text-5xl font-extrabold tracking-tight text-transparent drop-shadow-[0_2px_12px_rgba(255,200,100,0.25)] sm:text-6xl">
            FRILL STAR
            <br />
            ADVENTURE
          </h1>
          <p className="mt-3 text-sm font-medium text-white/70">フリルの星降る大冒険</p>
        </div>

        {/* フリル */}
        <div className="hn-float pointer-events-none my-2 sm:my-4">
          <canvas ref={canvasRef} />
        </div>

        {/* ボタン群（実DOMボタン＝押下位置ずれなし） */}
        <div className={`hn-fade-in flex w-full max-w-xs flex-col gap-3 ${isMobile ? 'mt-2' : 'mt-4'}`}>
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault()
              onPlay()
            }}
            className="flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-pink-500 via-rose-400 to-orange-400 py-4 text-lg font-extrabold text-white shadow-xl shadow-pink-500/25 transition-transform active:scale-95"
          >
            <Play size={22} className="fill-white" />
            プレイ
          </button>
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault()
              onPlay()
            }}
            className="flex items-center justify-center gap-2 rounded-2xl border border-white/20 bg-white/10 py-3.5 text-base font-bold text-white/90 backdrop-blur-sm transition-transform active:scale-95"
          >
            <Users size={19} />
            キャラ一覧
          </button>
        </div>

        {/* デスクトップのみ操作説明 */}
        {!isMobile && (
          <p className="mt-5 text-center text-[11px] leading-relaxed text-white/40">
            WASD / 矢印キー：移動　J / Space：攻撃　K：フリル・レイジ　L / Shift：ダッシュ
            <br />
            スマホでは左の仮想スティックと右のボタンで操作します
          </p>
        )}
      </div>

      {/* ===== 右下：コピーライト（ご指定どおり） ===== */}
      <div
        className="absolute bottom-3 right-4 select-none text-sm font-semibold text-white/75 drop-shadow-[0_1px_3px_rgba(0,0,0,0.5)]"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        ©🌟HoshiNet
      </div>
    </div>
  )
}
