'use client'

// ===== ゲーム画面：キャンバス＋HUD＋タッチ操作 =====
// 【タッチ判定の修正方針】
// ・ボタンは「実DOM要素」に直接 pointerdown を張る → ブラウザ本来の当たり判定を使うので
//   「表示位置より下を押さないと反応しない」ずれが構造的に起きない
// ・ジョイスティックの座標計算は毎イベント getBoundingClientRect() を取り直す
// ・touch-action: none でブラウザジェスチャ（スクロール・ズーム）を無効化
import { useEffect, useRef, useState, useCallback } from 'react'
import { GameEngine, type HUDState, type GameOverResult } from './engine'
import type { CharacterDef } from './characters'
import { Pause, Play, Home, RotateCcw } from 'lucide-react'

interface Props {
  character: CharacterDef
  isMobile: boolean
  onQuit: () => void
  onRestart: () => void
}

const emptyHUD: HUDState = {
  hp: 100,
  maxHP: 100,
  score: 0,
  kills: 0,
  wave: 1,
  time: 0,
  rageCd: 1,
  dashCd: 1,
  rageActive: false,
  intermission: 0,
}

export default function GameScreen({ character, isMobile, onQuit, onRestart }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const engineRef = useRef<GameEngine | null>(null)
  const [hud, setHud] = useState<HUDState>(emptyHUD)
  const [paused, setPaused] = useState(false)
  const [over, setOver] = useState<GameOverResult | null>(null)
  const pausedRef = useRef(false)

  // ---- エンジン起動 ----
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const engine = new GameEngine(canvas, {
      character,
      onHUD: setHud,
      onGameOver: (r) => setOver(r),
    })
    engineRef.current = engine
    engine.start()
    return () => {
      engine.destroy()
      engineRef.current = null
    }
  }, [character])

  // ---- 一時停止 ----
  const doPause = useCallback(() => {
    engineRef.current?.pause()
    pausedRef.current = true
    setPaused(true)
  }, [])
  const doResume = useCallback(() => {
    engineRef.current?.resume()
    pausedRef.current = false
    setPaused(false)
  }, [])

  // ---- スキル発動（ボタンから直接呼ぶ・判定ずれなし） ----
  const doRage = useCallback(() => {
    if (pausedRef.current) return
    engineRef.current?.tryRage()
  }, [])
  const doDash = useCallback(() => {
    if (pausedRef.current) return
    engineRef.current?.tryDash()
  }, [])
  const setAttack = useCallback((on: boolean) => {
    if (pausedRef.current) on = false
    engineRef.current?.setAttacking(on)
  }, [])

  // HPバーの色
  const hpRatio = hud.hp / hud.maxHP
  const hpColor = hpRatio > 0.5 ? '#4ade80' : hpRatio > 0.25 ? '#facc15' : '#f87171'

  const mm = Math.floor(hud.time / 60)
  const ss = Math.floor(hud.time % 60)

  // サイズ（スマホだけ縮小／デスクトップは従来どおり）
  const btnAttack = isMobile ? 'w-[64px] h-[64px] text-[26px]' : 'w-[84px] h-[84px] text-[34px]'
  const btnSkill = isMobile ? 'w-[56px] h-[56px] text-[22px]' : 'w-[76px] h-[76px] text-[30px]'
  const hudText = isMobile ? 'text-[11px]' : 'text-sm'
  const hudBarW = isMobile ? 'w-[140px]' : 'w-[200px]'

  return (
    <div
      className="game-root fixed inset-0 overflow-hidden bg-[#b4e0ac]"
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* ゲームキャンバス */}
      <canvas ref={canvasRef} className="absolute inset-0 block h-full w-full" />

      {/* ===== HUD（左上） ===== */}
      <div
        className={`pointer-events-none absolute left-2 top-2 sm:left-3 sm:top-3 ${isMobile ? 'space-y-1' : 'space-y-1.5'}`}
      >
        <div className="flex items-center gap-1.5">
          <span className="text-base sm:text-lg">💖</span>
          <div className={`h-3.5 ${isMobile ? 'h-3' : ''} overflow-hidden rounded-full border border-black/25 bg-black/35 ${hudBarW}`}>
            <div
              className="h-full rounded-full transition-[width] duration-200"
              style={{ width: `${hpRatio * 100}%`, background: hpColor }}
            />
          </div>
          <span className={`font-bold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)] ${hudText}`}>
            {hud.hp}/{hud.maxHP}
          </span>
        </div>
        <div className={`flex items-center gap-2 font-bold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)] ${hudText}`}>
          <span>⭐ {hud.score}</span>
          <span>👻 {hud.kills}</span>
          <span>🌊 Wave {hud.wave}</span>
          <span>
            ⏱ {mm}:{ss.toString().padStart(2, '0')}
          </span>
        </div>
      </div>

      {/* ===== 一時停止ボタン（右上） ===== */}
      <button
        type="button"
        aria-label="一時停止"
        onPointerDown={(e) => {
          e.preventDefault()
          doPause()
        }}
        className={`absolute right-2 top-2 flex items-center justify-center rounded-full border-2 border-white/60 bg-black/40 text-white backdrop-blur-sm active:scale-95 sm:right-3 sm:top-3 ${
          isMobile ? 'h-11 w-11' : 'h-12 w-12'
        }`}
      >
        <Pause size={isMobile ? 18 : 22} />
      </button>

      {/* ===== 操作ヒント（デスクトップのみ） ===== */}
      {!isMobile && (
        <div className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full bg-black/35 px-4 py-1.5 text-xs text-white/90 backdrop-blur-sm">
          WASD / 矢印キー：移動　J / Space：攻撃　K：フリル・レイジ　L / Shift：ダッシュ
        </div>
      )}

      {/* ===== タッチ操作（スマホのみ表示） ===== */}
      {isMobile && (
        <>
          {/* ---- 左：フローティングジョイスティック ---- */}
          <JoystickZone onMove={(x, y) => engineRef.current?.setMove(x, y)} disabled={paused || !!over} />

          {/* ---- 右：スキルボタン群（実DOMボタン＝当たり判定ずれなし） ---- */}
          <div className="absolute bottom-5 right-4 select-none" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
            <div className="relative flex items-end">
              {/* レイジ（左上） */}
              <div className="absolute bottom-[52px] left-[-8px]">
                <SkillButton
                  sizeClass={btnSkill}
                  label="💢"
                  subLabel="レイジ"
                  ready={hud.rageCd >= 1}
                  cdRatio={hud.rageCd}
                  totalCd={12}
                  active={hud.rageActive}
                  onPress={doRage}
                />
              </div>
              {/* ダッシュ（左下） */}
              <div className="mr-2 mb-1">
                <SkillButton
                  sizeClass={btnSkill}
                  label="💨"
                  subLabel="ダッシュ"
                  ready={hud.dashCd >= 1}
                  cdRatio={hud.dashCd}
                  totalCd={5}
                  active={false}
                  onPress={doDash}
                />
              </div>
              {/* 攻撃（メイン・最大） */}
              <button
                type="button"
                aria-label="攻撃"
                onPointerDown={(e) => {
                  e.preventDefault()
                  setAttack(true)
                }}
                onPointerUp={() => setAttack(false)}
                onPointerLeave={() => setAttack(false)}
                onPointerCancel={() => setAttack(false)}
                className={`flex flex-col items-center justify-center rounded-full border-[3px] border-white/80 bg-gradient-to-b from-amber-300 to-orange-400 font-bold text-white shadow-lg shadow-black/30 active:scale-90 transition-transform ${btnAttack}`}
              >
                <span className="drop-shadow-[0_1px_2px_rgba(0,0,0,0.4)]">⭐</span>
                <span className="text-[10px] drop-shadow-[0_1px_1px_rgba(0,0,0,0.4)]">攻撃</span>
              </button>
            </div>
          </div>
        </>
      )}

      {/* ===== Wave開始表示 ===== */}
      {hud.intermission > 0 && !over && (
        <div className="pointer-events-none absolute left-1/2 top-1/4 -translate-x-1/2 rounded-full bg-black/45 px-6 py-2 text-lg font-bold text-white backdrop-blur-sm">
          次のウェーブまで {Math.ceil(hud.intermission)}秒…
        </div>
      )}

      {/* ===== ポーズ画面 ===== */}
      {paused && !over && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/55 backdrop-blur-sm">
          <div className="hn-fade-in w-[86%] max-w-xs rounded-2xl border border-white/20 bg-[#241a3f] p-6 text-center shadow-2xl">
            <h2 className="mb-5 text-xl font-bold text-white">一時停止中</h2>
            <div className="space-y-3">
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault()
                  doResume()
                }}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-pink-400 to-rose-400 py-3.5 font-bold text-white shadow-lg active:scale-95"
              >
                <Play size={18} /> 再開する
              </button>
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault()
                  onQuit()
                }}
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/10 py-3.5 font-bold text-white active:scale-95"
              >
                <Home size={18} /> タイトルへ戻る
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== ゲームオーバー画面 ===== */}
      {over && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="hn-fade-in w-[88%] max-w-sm rounded-2xl border border-white/20 bg-[#241a3f] p-6 text-center shadow-2xl">
            <div className="mb-1 text-4xl">🌟</div>
            <h2 className="mb-4 text-2xl font-bold text-white">がんばった！</h2>
            <div className="mb-5 space-y-1.5 rounded-xl bg-black/25 p-4 text-sm text-white/90">
              <div className="flex justify-between">
                <span>スコア</span>
                <span className="text-lg font-bold text-amber-300">{over.score}</span>
              </div>
              <div className="flex justify-between">
                <span>たおした数</span>
                <span className="font-bold">{over.kills}</span>
              </div>
              <div className="flex justify-between">
                <span>到達ウェーブ</span>
                <span className="font-bold">Wave {over.wave}</span>
              </div>
              <div className="flex justify-between">
                <span>生存時間</span>
                <span className="font-bold">
                  {Math.floor(over.time / 60)}:{Math.floor(over.time % 60).toString().padStart(2, '0')}
                </span>
              </div>
            </div>
            <div className="space-y-3">
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault()
                  onRestart()
                }}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-pink-400 to-rose-400 py-3.5 font-bold text-white shadow-lg active:scale-95"
              >
                <RotateCcw size={18} /> もういちど
              </button>
              <button
                type="button"
                onPointerDown={(e) => {
                  e.preventDefault()
                  onQuit()
                }}
                className="flex w-full items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/10 py-3.5 font-bold text-white active:scale-95"
              >
                <Home size={18} /> タイトルへ戻る
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ===== ジョイスティック（左側・フローティング式） =====
function JoystickZone({ onMove, disabled }: { onMove: (x: number, y: number) => void; disabled: boolean }) {
  const zoneRef = useRef<HTMLDivElement>(null)
  const pointerId = useRef<number | null>(null)
  const origin = useRef({ x: 0, y: 0 })
  const [base, setBase] = useState<{ x: number; y: number } | null>(null)
  const [thumb, setThumb] = useState({ x: 0, y: 0 })
  const RADIUS = 52

  const start = (e: React.PointerEvent<HTMLDivElement>) => {
    if (disabled || pointerId.current !== null) return
    e.preventDefault()
    // 【修正】毎回最新の getBoundingClientRect() から正確に算出（判定ずれの根本原因を排除）
    const rect = zoneRef.current!.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    pointerId.current = e.pointerId
    origin.current = { x, y }
    setBase({ x, y })
    setThumb({ x: 0, y: 0 })
    onMove(0, 0)
  }

  const move = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pointerId.current !== e.pointerId) return
    e.preventDefault()
    const rect = zoneRef.current!.getBoundingClientRect()
    let dx = e.clientX - rect.left - origin.current.x
    let dy = e.clientY - rect.top - origin.current.y
    const d = Math.hypot(dx, dy)
    if (d > RADIUS) {
      dx = (dx / d) * RADIUS
      dy = (dy / d) * RADIUS
    }
    setThumb({ x: dx, y: dy })
    onMove(dx / RADIUS, dy / RADIUS)
  }

  const end = (e: React.PointerEvent<HTMLDivElement>) => {
    if (pointerId.current !== e.pointerId) return
    e.preventDefault()
    pointerId.current = null
    setBase(null)
    setThumb({ x: 0, y: 0 })
    onMove(0, 0)
  }

  return (
    <div
      ref={zoneRef}
      className="absolute bottom-0 left-0 h-[60%] w-[45%]"
      style={{ touchAction: 'none' }}
      onPointerDown={start}
      onPointerMove={move}
      onPointerUp={end}
      onPointerCancel={end}
      onPointerLeave={end}
    >
      {base && (
        <>
          {/* ベース */}
          <div
            className="pointer-events-none absolute h-[116px] w-[116px] rounded-full border-2 border-white/45 bg-black/25 backdrop-blur-[1px]"
            style={{ left: base.x - 58, top: base.y - 58 }}
          />
          {/* サブリング */}
          <div
            className="pointer-events-none absolute h-[60px] w-[60px] rounded-full border border-white/25"
            style={{ left: base.x - 30, top: base.y - 30 }}
          />
          {/* サム */}
          <div
            className="pointer-events-none absolute h-[54px] w-[54px] rounded-full border-2 border-white/70 bg-white/45 shadow-lg"
            style={{ left: base.x + thumb.x - 27, top: base.y + thumb.y - 27 }}
          />
        </>
      )}
      {!base && (
        <div className="pointer-events-none absolute bottom-6 left-6 flex h-[96px] w-[96px] items-center justify-center rounded-full border-2 border-dashed border-white/35 text-[10px] font-bold text-white/60">
          移動
        </div>
      )}
    </div>
  )
}

// ===== スキルボタン（クールダウン表示つき） =====
function SkillButton({
  sizeClass,
  label,
  subLabel,
  ready,
  cdRatio,
  totalCd,
  active,
  onPress,
}: {
  sizeClass: string
  label: string
  subLabel: string
  ready: boolean
  cdRatio: number // 0..1（1=使用可能）
  totalCd: number // クールダウン全体の秒数（残秒表示用）
  active: boolean
  onPress: () => void
}) {
  const deg = Math.round((1 - cdRatio) * 360)
  return (
    <button
      type="button"
      aria-label={subLabel}
      onPointerDown={(e) => {
        e.preventDefault()
        onPress()
      }}
      className={`relative flex flex-col items-center justify-center overflow-hidden rounded-full border-[3px] font-bold text-white shadow-lg shadow-black/30 transition-transform active:scale-90 ${sizeClass} ${
        active
          ? 'animate-pulse border-red-300 bg-gradient-to-b from-red-400 to-rose-600'
          : ready
            ? 'border-white/80 bg-gradient-to-b from-rose-400 to-pink-600'
            : 'border-white/40 bg-gradient-to-b from-slate-500 to-slate-700'
      }`}
    >
      <span className="drop-shadow-[0_1px_2px_rgba(0,0,0,0.4)]">{label}</span>
      <span className="text-[9px] leading-none drop-shadow-[0_1px_1px_rgba(0,0,0,0.4)]">{subLabel}</span>
      {/* クールダウン覆い（conic-gradient） */}
      {!ready && (
        <div
          className="absolute inset-0 rounded-full bg-black/55"
          style={{
            background: `conic-gradient(rgba(0,0,0,0.62) ${deg}deg, transparent ${deg}deg)`,
          }}
        />
      )}
      {!ready && (
        <span className="absolute inset-0 flex items-center justify-center text-sm font-bold text-white/90">
          {Math.ceil((1 - cdRatio) * totalCd)}
        </span>
      )}
    </button>
  )
}
