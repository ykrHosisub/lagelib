// ===== フリル＆キャラの描画（ちびキャラ・健全デザイン） =====
import type { CharacterDef } from './characters'

export interface AvatarAnimState {
  time: number // アニメ用経過時間（秒）
  moving: boolean
  facing: 1 | -1 // 1=右, -1=左
  rage: boolean // 怒り状態
  hurt: boolean
}

/** 柔らかい影 */
export function drawShadow(ctx: CanvasRenderingContext2D, x: number, y: number, r: number) {
  ctx.save()
  ctx.fillStyle = 'rgba(40, 25, 60, 0.18)'
  ctx.beginPath()
  ctx.ellipse(x, y, r, r * 0.38, 0, 0, Math.PI * 2)
  ctx.fill()
  ctx.restore()
}

/** 黄色い星（ヘアピン・エフェクト共通） */
export function drawStar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  color: string,
  rot = 0
) {
  ctx.save()
  ctx.translate(x, y)
  ctx.rotate(rot)
  ctx.fillStyle = color
  ctx.beginPath()
  for (let i = 0; i < 5; i++) {
    const a = -Math.PI / 2 + (i * Math.PI * 2) / 5
    const a2 = a + Math.PI / 5
    ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r)
    ctx.lineTo(Math.cos(a2) * r * 0.45, Math.sin(a2) * r * 0.45)
  }
  ctx.closePath()
  ctx.fill()
  ctx.restore()
}

/**
 * ちびキャラを描画。原点は足元。(x, y) に描く。
 * 高さはおよそ scale * 74px。
 */
export function drawCharacter(
  ctx: CanvasRenderingContext2D,
  ch: CharacterDef,
  x: number,
  y: number,
  scale: number,
  st: AvatarAnimState
) {
  const t = st.time
  const bob = st.moving ? Math.sin(t * 11) * 2.2 : Math.sin(t * 2.4) * 1.4
  const step = st.moving ? Math.sin(t * 11) : 0
  const f = st.facing

  drawShadow(ctx, x, y, 20 * scale)

  ctx.save()
  ctx.translate(x, y - bob * scale)
  ctx.scale(scale * f, scale) // f で左右反転（顔の向き）

  const rage = st.rage
  const hair = ch.hairColor
  const dress = ch.dressColor
  const accent = ch.accentColor

  // ---- 怒りオーラ（背後） ----
  if (rage) {
    const pulse = 0.7 + Math.sin(t * 9) * 0.3
    const g = ctx.createRadialGradient(0, -34, 4, 0, -34, 46)
    g.addColorStop(0, `rgba(255, 90, 60, ${0.32 * pulse})`)
    g.addColorStop(1, 'rgba(255, 90, 60, 0)')
    ctx.fillStyle = g
    ctx.beginPath()
    ctx.arc(0, -34, 46, 0, Math.PI * 2)
    ctx.fill()
  }

  // ---- 足 ----
  ctx.fillStyle = '#8a5a44'
  const legSwing = st.moving ? step * 3.2 : 0
  for (const s of [-1, 1]) {
    ctx.save()
    ctx.translate(s * 5.2, -4 - Math.max(0, s * legSwing))
    ctx.beginPath()
    ctx.ellipse(0, 0, 3.6, 4.6, 0, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }

  // ---- フリル付きドレス（3段） ----
  const sway = st.moving ? step * 2 : 0
  ctx.save()
  ctx.rotate(sway * 0.02)
  // 下段（スカート本体）
  ctx.fillStyle = dress
  ctx.beginPath()
  ctx.moveTo(-14, -4)
  ctx.quadraticCurveTo(-17, -16, -11, -24)
  ctx.lineTo(11, -24)
  ctx.quadraticCurveTo(17, -16, 14, -4)
  // 波型の裾
  for (let i = 0; i < 5; i++) {
    const px = 14 - i * 7
    ctx.quadraticCurveTo(px - 3.5, 1.5, px - 7, -4)
  }
  ctx.closePath()
  ctx.fill()
  // 腰のリボン帯
  ctx.fillStyle = ch.color
  ctx.fillRect(-11.5, -25, 23, 3.4)
  // 中央リボン
  ctx.beginPath()
  ctx.ellipse(-3.4, -23.2, 3, 2.2, -0.4, 0, Math.PI * 2)
  ctx.ellipse(3.4, -23.2, 3, 2.2, 0.4, 0, Math.PI * 2)
  ctx.fill()
  // 中段フリル
  ctx.fillStyle = accent
  for (let i = 0; i < 4; i++) {
    ctx.beginPath()
    ctx.arc(-8.6 + i * 5.8, -26.5, 2.9, 0, Math.PI * 2)
    ctx.fill()
  }
  // 上段（トップス）
  ctx.fillStyle = dress
  ctx.beginPath()
  ctx.moveTo(-9.5, -27)
  ctx.quadraticCurveTo(-10, -36, -6.5, -37)
  ctx.lineTo(6.5, -37)
  ctx.quadraticCurveTo(10, -36, 9.5, -27)
  ctx.closePath()
  ctx.fill()
  ctx.restore()

  // ---- 腕 ----
  ctx.strokeStyle = '#ffe3d0'
  ctx.lineWidth = 3.4
  ctx.lineCap = 'round'
  const armSwing = st.moving ? step * 4 : 0
  ctx.beginPath()
  ctx.moveTo(-8.5, -34)
  ctx.lineTo(-11.5, -27 + armSwing * 0.5)
  ctx.stroke()
  ctx.beginPath()
  ctx.moveTo(8.5, -34)
  ctx.lineTo(11.5, -27 - armSwing * 0.5)
  ctx.stroke()

  // ---- 後ろ髪 ----
  ctx.fillStyle = hair
  ctx.beginPath()
  ctx.ellipse(0, -47, 12.5, 12, 0, 0, Math.PI * 2)
  ctx.fill()

  // ---- ツインテール ----
  const tail = st.moving ? Math.sin(t * 11 + 1.2) * 2.4 : Math.sin(t * 2.6) * 1.6
  for (const s of [-1, 1]) {
    ctx.save()
    ctx.translate(s * 12, -50)
    ctx.rotate(s * (0.5 + tail * 0.03))
    ctx.fillStyle = hair
    ctx.beginPath()
    ctx.moveTo(0, 0)
    ctx.quadraticCurveTo(s * 6.5, 7, s * 4.5, 15 + tail)
    ctx.quadraticCurveTo(s * 2, 19, 0, 14)
    ctx.quadraticCurveTo(s * -1.5, 7, 0, 0)
    ctx.fill()
    // 髪飾りのシュシュ
    ctx.fillStyle = accent
    ctx.beginPath()
    ctx.arc(0, 1.5, 2.6, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }

  // ---- 顔 ----
  ctx.fillStyle = '#ffe3d0'
  ctx.beginPath()
  ctx.arc(0, -46, 10.4, 0, Math.PI * 2)
  ctx.fill()

  // ---- 前髪 ----
  ctx.fillStyle = hair
  ctx.beginPath()
  ctx.arc(0, -47.5, 10.8, Math.PI * 1.02, Math.PI * 1.98)
  ctx.quadraticCurveTo(9.5, -43.5, 6.4, -44.6)
  ctx.quadraticCurveTo(4.4, -41.6, 1.8, -43.2)
  ctx.quadraticCurveTo(0.2, -40.4, -2.6, -42.4)
  ctx.quadraticCurveTo(-5, -39.8, -7.2, -42.8)
  ctx.quadraticCurveTo(-9.6, -41.2, -10.6, -43.6)
  ctx.closePath()
  ctx.fill()

  // ---- 目・口（喜怒表現） ----
  if (rage) {
    // 怒り：>_< の目
    ctx.strokeStyle = '#5a3a3a'
    ctx.lineWidth = 1.7
    ctx.beginPath()
    ctx.moveTo(2.2, -47.5)
    ctx.lineTo(5.4, -46)
    ctx.lineTo(2.2, -44.6)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(-2.2, -47.5)
    ctx.lineTo(-5.4, -46)
    ctx.lineTo(-2.2, -44.6)
    ctx.stroke()
    // 不満な口
    ctx.beginPath()
    ctx.arc(0, -40.4, 2.4, Math.PI * 1.15, Math.PI * 1.85)
    ctx.stroke()
    // 怒りマーク
    const px = 11
    const py = -58
    ctx.strokeStyle = '#ff5a3c'
    ctx.lineWidth = 2
    for (const s of [-1, 1]) {
      ctx.beginPath()
      ctx.moveTo(px - 3 * s, py - 3.6)
      ctx.quadraticCurveTo(px + 0.6 * s, py, px - 3 * s, py + 3.6)
      ctx.stroke()
    }
  } else {
    // 普段：キラキラ目
    ctx.fillStyle = '#4a3348'
    for (const s of [1, -1]) {
      ctx.beginPath()
      ctx.ellipse(s * 3.8, -46, 1.9, 2.5, 0, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = '#ffffff'
      ctx.beginPath()
      ctx.arc(s * 3.8 + 0.7, -47, 0.75, 0, Math.PI * 2)
      ctx.fill()
      ctx.fillStyle = '#4a3348'
    }
    // にっこり口
    ctx.strokeStyle = '#c46a6a'
    ctx.lineWidth = 1.2
    ctx.beginPath()
    ctx.arc(0, -43.4, 2.2, Math.PI * 0.12, Math.PI * 0.88)
    ctx.stroke()
  }
  // ほっぺ
  ctx.fillStyle = 'rgba(255, 130, 150, 0.45)'
  ctx.beginPath()
  ctx.arc(6.4, -43, 1.9, 0, Math.PI * 2)
  ctx.arc(-6.4, -43, 1.9, 0, Math.PI * 2)
  ctx.fill()

  // ---- 星のヘアピン ----
  drawStar(ctx, 7.6, -53, 3, accent)

  ctx.restore()
}
