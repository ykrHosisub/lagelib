'use client'

// ===== HoshiNet スプラッシュ（起動時に最初に表示するブランドロゴ） =====
import { useEffect, useRef, useState } from 'react'

export default function SplashScreen({ onDone }: { onDone: () => void }) {
  const [leaving, setLeaving] = useState(false)
  const done = useRef(false)

  const finish = () => {
    if (done.current) return
    done.current = true
    setLeaving(true)
    window.setTimeout(onDone, 420)
  }

  useEffect(() => {
    const t = window.setTimeout(finish, 2600)
    return () => window.clearTimeout(t)
  })

  return (
    <div
      className={`game-root fixed inset-0 flex flex-col items-center justify-center bg-[#1a1030] transition-opacity duration-400 ${
        leaving ? 'opacity-0' : 'opacity-100'
      }`}
      onPointerDown={() => finish()}
      role="button"
      aria-label="HoshiNet ロゴ、タップでスキップ"
    >
      {/* 背景の星空 */}
      <div className="hn-starfield pointer-events-none absolute inset-0 opacity-70" />
      <div className="pointer-events-none absolute left-[18%] top-[24%] text-xl hn-twinkle" style={{ animationDelay: '0.3s' }}>
        ✦
      </div>
      <div className="pointer-events-none absolute right-[22%] top-[32%] text-sm hn-twinkle" style={{ animationDelay: '0.9s' }}>
        ✦
      </div>
      <div className="pointer-events-none absolute bottom-[30%] left-[30%] text-sm hn-twinkle" style={{ animationDelay: '1.4s' }}>
        ✦
      </div>
      <div className="pointer-events-none absolute bottom-[26%] right-[28%] text-lg hn-twinkle" style={{ animationDelay: '0.6s' }}>
        ✦
      </div>

      {/* ロゴ本体 */}
      <div className="relative flex flex-col items-center">
        {/* パルスリング */}
        <div className="pointer-events-none absolute left-1/2 top-1/2 h-36 w-36 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-amber-300/50 hn-ring" />
        {/* スターのマーク */}
        <div className="hn-star-pop relative select-none">
          <div className="text-[72px] leading-none hn-float drop-shadow-[0_0_24px_rgba(255,215,110,0.55)]">🌟</div>
        </div>
        {/* ワードマーク */}
        <div className="hn-fade-in mt-5 text-center" style={{ animationDelay: '0.5s' }}>
          <div className="bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 bg-clip-text text-4xl font-extrabold tracking-wide text-transparent">
            HoshiNet
          </div>
          <div className="mt-2 text-[11px] font-medium uppercase tracking-[0.35em] text-white/50">
            presents
          </div>
        </div>
      </div>

      {/* 下部 */}
      <div className="hn-fade-in absolute bottom-8 text-[11px] text-white/40" style={{ animationDelay: '1.1s' }}>
        tap to skip
      </div>
    </div>
  )
}
